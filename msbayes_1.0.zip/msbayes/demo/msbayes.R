##	the demo states how to use the msbayes package for methylation level estimation #####


library(msbayes)

library(R2WinBUGS)
library(boa)

data(methyl.seq)
data(genome.seq.diff.adj)

seq.dep.bias <- genome.seq.diff.adj$seq.dep.bias

dat <- methyl.seq[,-c(1,2)]; 
rownames(dat) <- methyl.seq[,2]

######## methyl.bayes.site #########

site.est <- matrix(NA,ncol=ncol(dat)-1, nrow=nrow(dat))

for (k in 1:nrow(dat)){
data.temp <- dat[k,,drop=FALSE]
input <- as.matrix(data.temp)
feed <- methyl.bayes.site(input,seq.dep.bias);
site.est[k,]<-feed[,2];
}

rownames(site.est) <- rownames(methyl.seq)
site.est

####### methyl.bayes.region #########
input <- dat
region.est <- methyl.bayes(input,seq.dep.bias)

####### plot #############

methyl.bayes.plot(methyl.seq,site.est,region.est)


####### RRBS data analysis)
input <- rrbs.sim(25,0.7)
rrbs.bayes(input)


